//Write a code to print fibonacci number till 100

var x =0, y=1;

z=x+y;
while(z<=100){
    console.log(z);
    x=y;
    y=z;
    z=x+y;
}
