var greet = require("./greeting.js");

greet();