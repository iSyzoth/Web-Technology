var fs= require("fs")

var read=fs.readFileSync("dummy.txt")
console.log(read = read.toString())
