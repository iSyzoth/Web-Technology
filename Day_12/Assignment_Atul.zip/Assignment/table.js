//Write a code to write table of 3 to file

for (var i=1; i<=10; i++){
    console.log(`3 × ${i} = ${3 * i}`);
}